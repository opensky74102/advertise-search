<?php
header('location: /');